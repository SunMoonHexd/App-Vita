// DATOS PRIVADOS DE JaaS. Este archivo NO debe subirse a GitHub
// (agrega la línea  lib/config/jaas_secrets.dart  a tu .gitignore).
//
// 1) App ID:  en la consola de JaaS (jaas.8x8.vc), algo como  vpaas-magic-cookie-xxxxxxxx
// 2) Key ID:  al crear la API Key, algo como  vpaas-magic-cookie-xxxxxxxx/abc123
//             (incluye el prefijo y la barra: cópialo completo)
// 3) Clave privada: abre el archivo .pem/.pk que descargaste con el Bloc de notas y pega
//             TODO su contenido (incluidas las líneas BEGIN y END) entre las comillas triples.

const String kJaasAppId = 'vpaas-magic-cookie-25df90a0903941bea6638c59cd3fc37e';

const String kJaasKeyId = 'vpaas-magic-cookie-25df90a0903941bea6638c59cd3fc37e/f7a1aa';

const String kJaasPrivateKey = '''
-----BEGIN PRIVATE KEY-----
MIIEuwIBADANBgkqhkiG9w0BAQEFAASCBKUwggShAgEAAoIBAQCUjxM4puBjC0wl
jEfhYFOdQAn7yZBgrS2m3nWQIlcCJrYl6Ijeuu9ckuysXgSFMN061WLcjSqk5VE4
1+XnnSgM+1yE57HvmKdVIMisGthj6Lzb6tXRq+j/tZm3fVfV09B88DHIEUxXcmgg
G4cj3kpCc69dMI6qXW2aFKsE86xD7U0ox0RJMTHsroREo8JVdlDc39+Kt6vKm5zt
9I3u8Bjcl2AANe2pDzda2ZzVimgsyy6qV4K9jOMJMSjGrDZraaqjK9hC1VRMPdUW
OKuGAG/02f6rpGe/fN4qlVwILezZqorqeWxMKQLIMpQdvTwzP2690mJ/gIv+Gfrz
10+rzoM9AgMBAAECggEARMB6SsugKPY/hVkIoxsrVykd9bLw6Gz9Ja7qhYv+7HXx
8lVNkpa81AEDGzpfqSxWFjZPDHcgdzPRhRcVxT0MHgXuaWu5A4OIXXNQq6W443QA
g16JGgIPUNhAjZSqo8DlSgz3XPn0dLvzyHg08Lqdb2eOjvg77khSwu4xv5bt8Hkb
i1T/kXx7OvC6OKtwFBJerXc0yUg3YPFhBoz3oEXRjRuJoeLFJLefQdu43hC0deGg
9xQeKWt9HvBXDH6GRE8+4IK1+2uQjG47lzUXdQLE0Oy8a93tvmMZfae0NAzaL5oK
dJjX64V/2wU89UtMR7f/jACWcWUnha8GawI1CZ3DWQKBgQDKl84Whv22XoBPN8Da
tmRc73zM20vMM7d1+O47usj+xoj0yzNOa1Ud8DGbuxdx0Hb+vXlo9mC/IuRdu6em
QQiR8oqR6DaqO5MGg2ufWierUoGvYxwUHm1N7m98gctdUuJFf7seER+Y3gEoVr4a
YyybC8AWJ7JineF4oouc1l8e+wKBgQC7uLk1iWEbGjVjgwoHT6QvuJnmeEeXMaqf
QGX3nCTs/T+9HlGdxtyNtsxPJVdF6m6h7vOhXrLyd+/Lwwp7YMYee3EGW2rBbay/
gOJuHSQ6PxsA5l3f0q8J/bZGMnX0dDpremozQHGOx0p0pvii8ZR2T14Fw4a2re+m
YAK4wqxxJwKBgCDlua9qyDQe8FLsyMI7L9zvfqJ9UbedBkN/4p+MWysT7hViEbjA
MRglcsjI/quaoFgJSHfE2jzvW4nk+PpEQTIB4oKC5K2L8vnxyT4dE6f8Q9bJDzwt
HK608yGSqgVDej6y2R2uxiS6mBGG1GPQiuO6aryuQYdF/+Do9CbJoLSVAn9PMZ7w
9wQAaw4a7S1N6Etb1oUWtad+IXXZuVFLJJRvZmd9YU0NQtfI8VVADoDC/iOuLSCa
81iK8g436BCD/E+YjHsiM27WK261W6oqyiB+ciDyQD1aL4eor2A2PROGDYKX1Qz4
kjdWBL1keQxrsX7waos/4zzx1G9FwTtktrwJAoGBAJpaTpilW7HYfSD7CyHWaUOp
qiuCsDJXov1dYoY+ab7WCQqqCjTH0UxdlvrQ2GjRKsuTzC83BOWxHw58vVRne5k9
6BNYh0hCLbgSAk8iHE+yNWsyAMubcp32yalWmEtQDURwcELSecP8IacZLWEBpO7m
asdxD1FUNm79ub+EL3xb
-----END PRIVATE KEY-----
''';

bool get jaasConfigured =>
    kJaasAppId.startsWith('vpaas-magic-cookie-') &&
    kJaasKeyId.startsWith('vpaas-magic-cookie-') &&
    kJaasPrivateKey.contains('BEGIN') &&
    kJaasPrivateKey.contains('PRIVATE KEY');
